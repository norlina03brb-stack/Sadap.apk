package com.kyriel.flash

import android.Manifest
import android.app.*
import android.app.WallpaperManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.InputStream

class MainActivity : Activity() {
    private lateinit var cameraManager: CameraManager
    private var cameraId: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private var blinking = false
    private var interval = 500L

    private val blink = object : Runnable {
        private var on = false
        override fun run() {
            if (!blinking) return
            cameraId?.let { id ->
                try {
                    on = !on
                    cameraManager.setTorchMode(id, on)
                } catch (_: Exception) {
                    blinking = false
                    findViewById<TextView>(R.id.status).text = "Senter tidak tersedia."
                    return
                }
            }
            handler.postDelayed(this, interval)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }

        val status = findViewById<TextView>(R.id.status)
        val start = findViewById<Button>(R.id.start)
        val stop = findViewById<Button>(R.id.stop)
        val speed = findViewById<SeekBar>(R.id.speed)
        val speedText = findViewById<TextView>(R.id.speedText)

        speed.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                interval = (p + 100).toLong()
                speedText.text = "$interval ms"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        start.setOnClickListener {
            if (cameraId == null) {
                status.text = "Perangkat tidak punya LED flash."
                return@setOnClickListener
            }
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 10)
                status.text = "Izinkan kamera agar LED flash dapat dikontrol."
                return@setOnClickListener
            }
            stopBlink()
            blinking = true
            status.text = "Senter sedang berkedip."
            handler.post(blink)
        }

        stop.setOnClickListener {
            stopBlink()
            status.text = "Kedipan dihentikan."
        }

        findViewById<Button>(R.id.pick).setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(intent, 20)
        }
    }

    private fun stopBlink() {
        blinking = false
        handler.removeCallbacks(blink)
        cameraId?.let {
            try { cameraManager.setTorchMode(it, false) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        stopBlink()
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 20 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val bitmap = BitmapFactory.decodeStream(input)
                val wm = WallpaperManager.getInstance(this)
                wm.setBitmap(bitmap)
                Toast.makeText(this, "Wallpaper berhasil dipasang.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memasang wallpaper: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
