@echo off
setlocal
if not exist ".gradle\gradle-8.7\bin\gradle.bat" (
  powershell -Command "Invoke-WebRequest -Uri https://services.gradle.org/distributions/gradle-8.7-bin.zip -OutFile .gradle.zip"
  powershell -Command "Expand-Archive -Force .gradle.zip .gradle"
)
call .gradle\gradle-8.7\bin\gradle.bat %*
