# Kyriel Flash — GitHub Actions Build

## Cara build dari HP

1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini ke repository.
3. Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.
4. Buka tab **Actions**.
5. Pilih **Build Kyriel Flash APK**.
6. Tekan **Run workflow** jika workflow belum otomatis berjalan.
7. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
8. Download `KyrielFlash-debug`.
9. Extract ZIP artifact tersebut untuk mendapatkan `app-debug.apk`.

Workflow menggunakan JDK 17 dan Gradle 8.7 pada runner Ubuntu GitHub. Android SDK tersedia di runner GitHub dan Gradle Android plugin akan mengambil komponen SDK yang diperlukan.

## Catatan

APK debug ditujukan untuk instalasi/testing. Untuk distribusi publik, gunakan signing/release build dengan Android keystore yang aman.
